name = "Monica Muyama"
age = 20
print ( "Hello "+ name "welcome to our course")